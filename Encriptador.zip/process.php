<?php
$servername = "localhost";
$username = "id21300105_jvaldez";
$password = "Al_175423";
$dbname = "id21300105_gasrt";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $texto = $_POST['texto'];
    $action = $_POST['action'];

    if ($action == 'encrypt') {
        $texto_encriptado = base64_encode($texto);

        $stmt = $conn->prepare("INSERT INTO mensajes (texto_original, texto_encriptado) VALUES (?, ?)");
        $stmt->bind_param("ss", $texto, $texto_encriptado);
        $stmt->execute();
        $stmt->close();

        header("Location: index.php?resultado=" . urlencode($texto_encriptado));
        exit(); // Asegura que el script se detenga después de la redirección
    } elseif ($action == 'decrypt') {
        $texto_desencriptado = base64_decode($texto);

        header("Location: index.php?resultado=" . urlencode($texto_desencriptado));
        exit(); // Asegura que el script se detenga después de la redirección
    }
}

$conn->close();
?>