<?php
header('Content-Type: application/json');
$servername = "localhost";
$username = "id21300105_jvaldez";
$password = "Al_175423";
$dbname = "id21300105_gasrt";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$data = json_decode(file_get_contents('php://input'), true);
$original = $data['original'];
$encrypted = $data['encrypted'];

$stmt = $conn->prepare("INSERT INTO mensajes (texto_original, texto_encriptado) VALUES (?, ?)");
$stmt->bind_param("ss", $original, $encrypted);
$stmt->execute();
$stmt->close();
$conn->close();

echo json_encode(['status' => 'success']);
?>
