<?php
header('Content-Type: application/json');
$servername = "localhost";
$username = "id21300105_jvaldez";
$password = "Al_175423";
$dbname = "id21300105_gasrt";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$data = json_decode(file_get_contents('php://input'), true);
$encrypted = $data['encrypted'];

$stmt = $conn->prepare("SELECT texto_original FROM mensajes WHERE texto_encriptado = ?");
$stmt->bind_param("s", $encrypted);
$stmt->execute();
$stmt->bind_result($original);
$stmt->fetch();
$stmt->close();
$conn->close();

echo json_encode(['original' => $original]);
?>
