function encryptText() {
    const textArea = document.getElementById('texto');
    const resultArea = document.getElementById('resultado');
    const text = textArea.value;

    // Encriptar el texto usando base64
    const encryptedText = btoa(text);
    resultArea.textContent = encryptedText;

    // Guardar en la base de datos
    saveToDatabase(text, encryptedText);
}

function decryptText() {
    const textArea = document.getElementById('texto');
    const resultArea = document.getElementById('resultado');
    const text = textArea.value;

    // Desencriptar el texto usando base64
    try {
        const decryptedText = atob(text);
        resultArea.textContent = decryptedText;
    } catch (e) {
        // Intentar recuperar de la base de datos
        fetchFromDatabase(text);
    }
}

function saveToDatabase(originalText, encryptedText) {
    fetch('save.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ original: originalText, encrypted: encryptedText })
    })
    .then(response => response.json())
    .then(data => console.log(data))
    .catch(error => console.error('Error:', error));
}

function fetchFromDatabase(encryptedText) {
    fetch('fetch.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ encrypted: encryptedText })
    })
    .then(response => response.json())
    .then(data => {
        const resultArea = document.getElementById('resultado');
        if (data.original) {
            resultArea.textContent = data.original;
        } else {
            resultArea.textContent = 'No se encontró el texto original para la cadena encriptada proporcionada.';
        }
    })
    .catch(error => console.error('Error:', error));
}