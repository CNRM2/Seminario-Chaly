<?php
// Conexión a la base de datos
$servername = "localhost";
$dBUsername = "id21300105_jvaldez";
$dBPassword = "Al_175423";
$dBName = "id21300105_gasrt";

// Crear conexión
$conn = new mysqli($servername, $dBUsername, $dBPassword, $dBName);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión a la base de datos: " . $conn->connect_error);
}

// Consulta SQL para obtener el último dato con led_id = 1
$sql = "SELECT * FROM Sensor_Data WHERE id = 1 ORDER BY timestamp DESC LIMIT 1";
$result = $conn->query($sql);

// Verificar si se encontraron resultados
if ($result->num_rows > 0) {
    // Obtener el único resultado
    $row = $result->fetch_assoc();

    // Devolver los datos en formato JSON
    echo json_encode($row);
} else {
    echo "0 resultados";
}
$conn->close();
?>
