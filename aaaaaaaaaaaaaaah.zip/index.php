<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Control de Bomba de Agua y Boiler :)</title>
    <link href="menu.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <nav>
        <ul>
            <li><a href="#">Encendido de</a>
                <div class="submenu">
                    <ul>
                        <li><a href="#" onclick="controlBomba('turn_on')">Bomba</a></li>
                        <li><a href="/on2">Boiler</a></li>
                        <li><a href="/on3">Foco</a></li>
                    </ul>
                </div>
            </li>
            <li><a href="#">Apagado</a>
                <div class="submenu">
                    <ul>
                        <li><a href="#" onclick="controlBomba('turn_off')">Bomba</a></li>
                        <li><a href="/off2">Boiler</a></li>
                        <li><a href="/off3">Foco</a></li>
                    </ul>
                </div>
            </li>
            <li><a href="/acerca">Acerca de</a></li>
        </ul>
    </nav>

    <br> </br>
    <br> </br>
    <br> </br>
    <br> </br>
    <br> </br>
    <br> </br>
    <br> </br>
    <br> </br>

    <?php
    $servername = "localhost";
    $dBUsername = "id21300105_jvaldez";
    $dBPassword = "Al_175423";
    $dBName = "id21300105_gasrt";

    $conn = mysqli_connect($servername, $dBUsername, $dBPassword, $dBName);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Inicializa la respuesta
    $response = array();

    // Comprobar si se recibió un comando para controlar la bomba (LED) desde la aplicación
    if (isset($_POST['control_command'])) {
        $command_recibido = $_POST['control_command'];
        
        // Realizar la acción correspondiente según el comando recibido
        if ($command_recibido === 'turn_on' || $command_recibido === 'turn_off') {
            // Actualiza la columna "command" en la base de datos con el nuevo comando
            $sql = "UPDATE Sensor_Data SET command = '$command_recibido' WHERE id = 1"; // Cambia 1 por el ID correcto si es necesario
            $result = mysqli_query($conn, $sql);
            
            if ($result) {
                // Actualización exitosa, no es necesario agregar más al JSON de respuesta
            } else {
                $response['error'] = 'Error al actualizar el comando en la base de datos: ' . mysqli_error($conn);
            }
        } else {
            $response['error'] = 'Comando no válido';
        }
    } else {
        // Si no se recibió un comando, obtén el valor de humedad, estado del LED y el comando
        $sql = "SELECT humidity, led_status, command FROM Sensor_Data WHERE id = 1"; // Cambia 1 por el ID correcto si es necesario
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);

        $humidity = $row['humidity'];
        $ledStatus = $row['led_status'];
        $command = $row['command']; // Obtén el comando almacenado en la base de datos

        // Agrega los datos al JSON de respuesta
        $response['humidity'] = $humidity;
        $response['led_status'] = $ledStatus;
        $response['command'] = $command;
    }
    ?>

    <h5>
        <p>Bomba: <strong>%STATE1%</strong> &nbsp;&nbsp; Boiler: <strong>%STATE2%</strong> &nbsp; Foco: <strong>%STATE3%</strong></p>
    </h5>
    <h5>
        <p>Temperatura: <strong>%STATE4%</strong> &nbsp;&nbsp; Presión: <strong>%STATE5%</strong> &nbsp; Humedad: <strong><?php echo $response['humidity']; ?></strong></p>
    </h5>
    <h5>
        <p>Estado del LED: <strong><?php echo $response['led_status']; ?></strong> &nbsp;&nbsp; Comando: <strong><?php echo $response['command']; ?></strong></p>
    </h5>

    <script type="text/javascript">
        function controlBomba(command) {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "index.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        location.reload();
                    } else {
                        alert("Error al actualizar el estado de la bomba.");
                    }
                }
            };
            xhr.send("control_command=" + command);
        }

        function actualizar() {
            location.reload(true);
        }
        setInterval("actualizar()", 4000);
    </script>
</body>
</html>
